package com.example.calculator

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast



//import android.widget.Button
//import android.widget.EditText
//import android.widget.TextView
//import androidx.appcompat.app.AppCompatActivity
//import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {


    private lateinit var number1: EditText
    private lateinit var number2: EditText
    private lateinit var answer: TextView
    private lateinit var buttonAdd: Button
    private lateinit var buttonSub: Button
    private lateinit var buttonMul: Button
    private lateinit var buttonDivide: Button
    private lateinit var buttonSqrt: Button
    private lateinit var buttonPower: Button
    private lateinit var buttonStats: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        number1 = findViewById(R.id.num1)
        number2 = findViewById(R.id.num2)
        answer = findViewById(R.id.answer)
        buttonAdd = findViewById(R.id.buttonAdd)
        buttonSub = findViewById(R.id.buttonSub)
        buttonMul = findViewById(R.id.buttonMul)
        buttonDivide = findViewById(R.id.buttonDiv)
        buttonSqrt = findViewById(R.id.buttonSq)
        buttonPower = findViewById(R.id.buttonPow)
        buttonStats = findViewById(R.id.buttonStat)

        buttonAdd.setOnClickListener {
            performAddition()
        }

        buttonSub.setOnClickListener {
            performSubtraction()
        }

        buttonMul.setOnClickListener {
            performMultiplication()
        }

        buttonDivide.setOnClickListener {
            performDivision()
        }

        buttonSqrt.setOnClickListener {
            performSquareRoot()
        }

        buttonPower.setOnClickListener {
            performPower()
        }

        buttonStats.setOnClickListener {
            performStatistics()
        }
    }

    private fun performStatistics() {
        TODO("Not yet implemented")
        val intent = Intent(this, MainActivity2::class.java)
        startActivity(intent)
    }

    private fun performAddition() {
        val num1 = number1.text.toString().toDouble()
        val num2 = number2.text.toString().toDouble()
        val result = num1 + num2
        answer.text = "Result: $result"
    }

    private fun performSubtraction() {
        val num1 = number1.text.toString().toDouble()
        val num2 = number2.text.toString().toDouble()
        val result = num1 - num2
        answer.text = "Result: $result"
    }

    private fun performMultiplication() {
        val num1 = number1.text.toString().toDouble()
        val num2 = number2.text.toString().toDouble()
        val result = num1 * num2
        answer.text = "Result: $result"
    }

    private fun performDivision() {
        val num1 = number1.text.toString().toDouble()
        val num2 = number2.text.toString().toDouble()
        if (num2 != 0.0) {
            val result = num1 / num2
            answer.text = "Result: $result"
        } else {
            answer.text = "Cannot divide by zero"
        }
    }

    private fun performSquareRoot() {
        val num1 = number1.text.toString().toDouble()
        val result = sqrt(num1)
        answer.text = "Result: $result"
    }

    private fun performPower() {
        val num1 = number1.text.toString().toDouble()
        val num2 = number2.text.toString().toDouble()
        val result = Math.pow(num1, num2)
        answer.text = "Result: $result"
    }


}


