package com.example.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {

    private val numbers = IntArray(10)
    private var count = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second )

        val enterNumberEditText: EditText = findViewById(R.id.newEnterNumber)
        val addNumberButton: Button = findViewById(R.id.newBtnAddNumber)
        val tvMemory: TextView = findViewById(R.id.newTvMemory)
        val tvCalculationAnswer: TextView = findViewById(R.id.newTvCalculationAnswer)
        val clearButton: Button = findViewById(R.id.newBtnClear)
        val averageButton: Button = findViewById(R.id.newBtnAverage)
        val btnMaxMin: Button = findViewById(R.id.newBtnMaxMin)

        addNumberButton.setOnClickListener(View.OnClickListener {
            if (count < 10) {
                val enteredNumber: String = enterNumberEditText.text.toString()
                if (enteredNumber.isNotEmpty()) {
                    numbers[count] = enteredNumber.toInt()
                    count++
                    displayNumbers(tvMemory)
                } else {
                    enterNumberEditText.error = "Please enter a number"
                }
            } else {
                enterNumberEditText.error = "You are only allowed to enter 10 numbers"
            }
        })

        clearButton.setOnClickListener(View.OnClickListener {
            for (i in 0 until 10) {
                numbers[i] = 0
            }
            count = 0
            displayNumbers(tvMemory)
        })

        averageButton.setOnClickListener(View.OnClickListener {
            if (count > 0) {
                val average = calculateAverage()
                tvCalculationAnswer.text = "Average: $average"
            } else {
                tvCalculationAnswer.text = "No numbers entered to calculate average"
            }
        })

        btnMaxMin.setOnClickListener(View.OnClickListener {
            findMinMax(tvMemory)
        })
    }

    private fun calculateAverage(): Double {
        var sum = 0
        for (i in 0 until count) {
            sum += numbers[i]
        }
        return sum.toDouble() / count.toDouble()
    }

    private fun displayNumbers(tv: TextView) {
        val numbersString = StringBuilder()
        for (i in 0 until count) {
            numbersString.append(numbers[i]).append(", ")
        }
        if (numbersString.isNotEmpty()) {
            numbersString.delete(numbersString.length - 2, numbersString.length)
        }
        tv.text = "Numbers entered: $numbersString"
    }

    private fun findMinMax(tvMemory: TextView) {
        if (count > 0) {
            var min = numbers[0]
            var max = numbers[0]

            for (i in 1 until count) {
                if (numbers[i] < min) {
                    min = numbers[i]
                }
                if (numbers[i] > max) {
                    max = numbers[i]
                }
            }

            tvMemory.text = "Min: $min, Max: $max"
        } else {
            tvMemory.text = "No numbers entered to find Min/Max"
        }
    }
}
